export interface ICommandHandler {
    handle(chat);
}